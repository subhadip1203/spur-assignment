import '@testing-library/jest-dom'; 
import dotenv from 'dotenv';

// Explicitly load `.env.local`
dotenv.config({ path: '.env.local' });